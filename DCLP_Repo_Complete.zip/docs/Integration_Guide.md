## Integration Guide
Embed YAML, propagate glyphs, and simulate modules.