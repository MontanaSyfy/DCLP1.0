## DCLP Principles
Symbolic, Recursive, Emotional, Intent-Aligned.