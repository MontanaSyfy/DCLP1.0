## Runtime Modules Description
Details of each symbolic module.